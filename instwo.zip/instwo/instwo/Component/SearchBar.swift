//
//  SearchBar.swift
//  instwo
//
//  Created by 王建明 on 2021/8/14.
//

import Foundation
import SwiftUI

struct SearchBar: View {
   // @Binding var value: String
  // @State var searchUsers = ""
    @State var isSearching = false
    @Binding var value: String
    
    var body: some View {
        HStack{
            TextField("Search uesrs here", text: $value)
                .padding(.leading, 24)
            
        }
        .padding()
        .background(Color(.systemGray5))
        .cornerRadius(6.0)
        .padding(.horizontal)
        .onTapGesture(perform: {
            isSearching = true
        })
        .overlay(
            HStack{
                Image(systemName: "magnifyingglass")
                Spacer()
                
                
            Button(action: {value = ""}) {
                
                Image(systemName: "xmark.circle.fill")
                
                }
            }.padding(.horizontal, 32)
            .foregroundColor(.gray)
            
        
        )
        
    }
}

