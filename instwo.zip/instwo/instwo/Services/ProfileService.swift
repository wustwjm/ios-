//
//  ProfileService.swift
//  instwo
//
//  Created by 王建明 on 2021/8/14.
//

import Foundation
import Firebase
import FirebaseAuth


class ProfileService: ObservableObject {
    
    
    @Published var posts: [PostModel] = []
    @Published var following = 0
    @Published var followers = 0
    
    @Published var followCheck = false
    
    
    static var following = AuthService.storeRoot.collection("following")
    
    static var followers = AuthService.storeRoot.collection("followers")
    
    
  
    
    static func followingId( userId: String) -> DocumentReference {
        return following.document(Auth.auth().currentUser!.uid).collection("following").document(userId)
    }
    
    static func followersId( userId: String) -> DocumentReference {
        return followers.document(userId).collection("followers").document(Auth.auth().currentUser!.uid)
    }
    
    static func followingCollection(userid: String) -> CollectionReference{
        return following.document(userid).collection("following")
        
    }
    
    static func followersCollection(userid: String) -> CollectionReference{
        return followers.document(userid).collection("followers")
        
    }
    
    func followState(userId: String) {
        ProfileService.followingId(userId: userId).getDocument {
            (document, error) in
            
            if let doc = document, doc.exists {
                self.followCheck = true
            } else {
                self.followCheck = false
            }
        }
    }
    
    
//    @Published var isLoading = false
    
    func loadUserPosts (userId: String) {
        //isLoading = true
        PostService.loadUserPosts(userId: userId) {
            (posts) in
            //elf.isLoading = false
            self.posts = posts
            //self.splitted = self.posts.splited(into: 3)
            
        }
        
        follows(userId: userId)
        followers(userId: userId)
        //checkFollow(userId: userId)
        //updateFollowCount(userId: userId)
    }
    
    func follows(userId: String) {
        ProfileService.followingCollection(userid: userId).getDocuments {
            (QuerySnapshot, err) in
            if let doc = QuerySnapshot?.documents {
                self.following = doc.count
            }
        }
    }
    
    
    func followers(userId: String) {
        ProfileService.followersCollection(userid: userId).getDocuments {
            (QuerySnapshot, err) in
            if let doc = QuerySnapshot?.documents {
                self.followers = doc.count
            }
        }
    }
    
}
