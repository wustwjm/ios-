//
//  PostServise.swift
//  instwo
//
//  Created by 王建明 on 2021/8/13.
//

import Foundation
import FirebaseAuth
import Firebase
import FirebaseFirestore
import FirebaseStorage

class PostService {
    
    static var Posts = AuthService.storeRoot.collection("posts")
    
    static var ALLPosts = AuthService.storeRoot.collection("allPosts")
    
    static var Timeline = AuthService.storeRoot.collection("timeline")
    
    
    
    static func PostsUserId(userId: String) -> DocumentReference {
        return Posts.document(userId)
    }
    
    static func TimelineUserId(userId: String) -> DocumentReference {
        return Timeline.document(userId)
    }
    
    static func uploadPost(caption: String,
                           imageData: Data,
                           onSuccess: @escaping() -> Void,
                           onError: @escaping(_ errorMessage: String) -> Void) {
        guard let uesrId = Auth.auth().currentUser?.uid else {
            return
        }
        let postId = PostService.PostsUserId(userId: uesrId).collection("posts").document().documentID
        
        let storagePostRef = StorageService.storagePostId(postId: postId)
        
        let metadata = StorageMetadata()
        metadata.contentType = "image/jpg"
        
        StorageService.savePostPhoto(userId: uesrId,
                                     caption: caption,
                                     postId: postId,
                                     imageData: imageData,
                                     metadata: metadata,
                                     storagePostRef: storagePostRef,
                                     onSuccess: onSuccess,
                                     onError: onError)
        
    }
    
    static func loadPost(postId: String, onSuccess: @escaping(_ post: PostModel) -> Void){
        PostService.ALLPosts.document(postId).getDocument {
            (snapshot, err) in
            
            guard let snap = snapshot else {
                print("Error")
                return
            }
            
            let dict = snap.data()
            
            guard let decode = try? PostModel.init(formDictionary: dict!) else {
                
                return
            }
            
            onSuccess(decode)
            
            
            

        }
    }
    
  
    
    static func loadUserPosts(userId: String, onSuccess: @escaping(_ posts: [PostModel]) -> Void) {
        
        PostService.PostsUserId(userId: userId).collection("posts").getDocuments{ (snapshot, error) in
            guard let snap = snapshot else {
                print("Error")
                return
            }
            
            var posts = [PostModel]()
            
            for doc in snap.documents {
                let dict = doc.data()
                guard let decoder = try? PostModel.init(formDictionary: dict)
                else {
                    return
                }
                posts.append(decoder)
            }
            onSuccess(posts)
        }
    }

}
