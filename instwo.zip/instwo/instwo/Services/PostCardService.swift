//
//  PostCardService.swift
//  instwo
//
//  Created by 王建明 on 2021/8/14.
//

import Foundation
import Firebase
import SwiftUI

class PostCardService : ObservableObject {
    
    @Published var post: PostModel!
    @Published var isliked = false
    
    func hasLikedPost(){
        isliked = (post.likes["\(Auth.auth().currentUser!.uid)"] == true) ? true : false
    }
    
    func like(){
        post.likeCount += 1
        isliked = true
        
        PostService.PostsUserId(userId: post.ownerId).collection("posts").document(post.postId).updateData(["likeCount" : post.likeCount, "likes.\(Auth.auth().currentUser!.uid)" : true])
        
        
        PostService.ALLPosts.document(post.postId).updateData(["likeCount" : post.likeCount, "likes.\(Auth.auth().currentUser!.uid)" : true])
        
        PostService.TimelineUserId(userId: post.ownerId).collection("timeline").document(post.postId).updateData(["likeCount" : post.likeCount, "likes.\(Auth.auth().currentUser!.uid)" : true])
    }
    
    func unlike(){
        post.likeCount -= 1
        isliked = false
        
        PostService.PostsUserId(userId: post.ownerId).collection("posts").document(post.postId).updateData(["likeCount" : post.likeCount, "likes.\(Auth.auth().currentUser!.uid)" : false])
        
        
        PostService.ALLPosts.document(post.postId).updateData(["likeCount" : post.likeCount, "likes.\(Auth.auth().currentUser!.uid)" : false])
        
        PostService.TimelineUserId(userId: post.ownerId).collection("timeline").document(post.postId).updateData(["likeCount" : post.likeCount, "likes.\(Auth.auth().currentUser!.uid)" : false])
    }
    
    
    
    
}
