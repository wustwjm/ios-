//
//  Notifications.swift
//  instwo
//
//  Created by 王建明 on 2021/8/13.
//

import SwiftUI

struct Notifications: View {
    var body: some View {
        Text("Notifications")
        
    }
}

struct Notifications_Previews: PreviewProvider {
    static var previews: some View {
        Notifications()
    }
}
