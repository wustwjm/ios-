//
//  MainInsView.swift
//  instwo
//
//  Created by 王建明 on 2021/8/20.
//

import SwiftUI

struct MainInsView: View {
    
    @State var offset: CGFloat = rect.width
    
    init() {
        
        UITabBar.appearance().isHidden = true
    }
    

    
    var body: some View {
        // Scrollable Tabs...
        
        GeometryReader{reader in
            let frame = reader.frame(in: .global)
            //since there are three Views...
            ScrollableTabBar(tabs: ["","",""], rect: frame, offset: $offset) {
                PostInsView(offset: $offset)
                
                HomeIns(offset: $offset)
                
                DirectInsView(offset: rect.width)   //xiugai
                
                
                
            }
            .ignoresSafeArea()
        }
        .ignoresSafeArea()
    }
}

struct MainInsView_Previews: PreviewProvider {
    static var previews: some View {
        MainInsView()
    }
}
