//
//  Search.swift
//  instwo
//
//  Created by 王建明 on 2021/8/13.
//

import SwiftUI

struct Search: View {
    var body: some View {
        UserProfile()
        
    }
}

struct Search_Previews: PreviewProvider {
    static var previews: some View {
        Search()
    }
}
