//
//  HomeView.swift
//  instwo
//
//  Created by 王建明 on 2021/8/13.
//

import SwiftUI


struct HomeView: View {
    
    
  
    var body: some View {
  //      let contentView = ContentView().environmentObject(SessionStore())
        
        NavigationView{
            
            CustomtabView()
                .navigationTitle("")
                .navigationBarTitleDisplayMode(.inline)
                .navigationBarHidden(true)
          
        
        }.accentColor(.red)
    }
}

var tabs = ["house.fill", "magnifyingglass", "camera.viewfinder", "heart.fill", "person.fill"]

struct CustomtabView: View {
    @State var selectedTab = "house.fill"
    @State var edge = UIApplication.shared.windows.first?.safeAreaInsets
    
   
    
    
    
    var body: some View{
        ZStack(alignment: Alignment(horizontal: .center, vertical: .bottom)){
            
            NavigationView{
            
            TabView(selection: $selectedTab) {
                Main()
                    .tag("house.fill")
                Search()
                    .tag("magnifyingglass")
               Post()
                    .tag("camera.viewfinder")
                Notifications()
                    .tag("heart.fill")
                Profile()
                    .tag("person.fill")
            }
           // .foregroundStyle(.regularMaterial)
        } .accentColor(.pink)
            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
            .ignoresSafeArea(.all, edges: .bottom)
           
            
            HStack(spacing: 5) {
                ForEach(tabs, id: \.self) {
                    image in
                    TabButton(image: image, selectedTab: $selectedTab)
                    
                    if image != tabs.last{
                        Spacer(minLength: 0)
                    }
                }
            }
            
            .padding(.horizontal, 10)
            .padding(.vertical)
            //.background(Color.white)
           // .clipShape(Capsule())圆形
            //.background(Color.black.opacity(0.15))
            //.padding(.horizontal)
            .padding(.bottom, edge!.bottom == 0 ? 20 : 0)
            
            
        }
        .ignoresSafeArea(.keyboard, edges: .bottom)
        .background(Color.black.opacity(0.05).ignoresSafeArea(.all, edges: .all))
    }
   
}

struct TabButton: View {
    var image: String
    
    @Binding var selectedTab: String
    
    var body: some View{
        Button(action: {selectedTab = image}) {
            
            Image(systemName: "\(image)")
                .font(.title2)
                .foregroundColor(selectedTab == image ? Color.gray : Color.black)
                .frame(maxWidth: .infinity)
                //.padding()
        }
        
    }
}


//***************************************************************//


