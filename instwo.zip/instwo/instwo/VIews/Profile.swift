//
//  Profile.swift
//  instwo
//
//  Created by 王建明 on 2021/8/13.
//

import SwiftUI
import FirebaseAuth
import SDWebImageSwiftUI

private let kImageSpace: CGFloat = 6

struct Profile: View {
    @EnvironmentObject var session : SessionStore
    @State private var selection = 1
    
    @StateObject var profileService = ProfileService()
    
    @State private var isLinkActive = false
    
    let twoColumns = [GridItem(), GridItem()]
    
    var body: some View {
        ScrollView {
            VStack {
                
                ProfileHeader(user: self.session.session, postsCount: profileService.posts.count, following: $profileService.following, followers: $profileService.followers)
                
                VStack(alignment: .leading){
                    Text(session.session?.bio ?? "")
                        .font(.headline)
                        .lineLimit(1)
                }
            
                
                NavigationLink(destination: EditProfile(session: self.session.session),
                               isActive: $isLinkActive) {
                
                Button(action: {self.isLinkActive = true}) {
                    Text("Edit Profile")
                        .font(.title)
                        .modifier(ButtonModifiers())
                        
                    
                }
                .padding(.horizontal)
                }
//滑动效果
                Picker("", selection: $selection) {
                    Image(systemName: "circle.grid.2x2.fill")
                        .tag(0)
                    Image(systemName: "person.circle")
                        .tag(1)
                }.pickerStyle(SegmentedPickerStyle()).padding(.horizontal)
                
                if selection == 1 {
                    
                   
                    LazyVGrid(columns: twoColumns) {
                        
                        ForEach(self.profileService.posts, id:\.postId) {
                            (post) in
                            
                            WebImage(url: URL(string: post.mediaUrl)!)
                           
                                .resizable()
                                .scaledToFill()
                                
                                //.resizable()  //缩放
                                  //保持宽高比
                                
                                //.aspectRatio(contentMode: .fill)
                                .frame(width: UIScreen.main.bounds.width/2,
                                       height: UIScreen.main.bounds.height/3)
                               
                                
                                
                               // .padding(.horizontal, 10)
                                .clipped()
                                

                           
                        }
                        Spacer()
                        //.padding(.horizontal)
                       // .padding(.vertical)
                    }.padding(.horizontal)
                }
                
                
                else
                if (self.session.session == nil) { Text("")}
                else {
                    
               
                    
                    ScrollView{
                        
                        VStack {
                            ForEach(self.profileService.posts, id:\.postId) {
                                (post) in
                                
                                PostCardImage(post: post)
                                PostCard(post: post)
                                
                            }
                        }
                        
                    }
                    
                }
                
                
                
                
            }
                
                
                }.navigationTitle("profile")
                .navigationBarTitleDisplayMode(.inline)
                
                .navigationBarItems(leading: Button(action: {}) {
                    NavigationLink(destination: UserProfile()){
                    Image(systemName: "person.fill")
                    }
                }, trailing: Button(action: {
                    self.session.logout()
                }) {
                    Image(systemName: "arrow.right.circle.fill")
                    
            })
            .onAppear{
                self.profileService.loadUserPosts(userId: Auth.auth().currentUser!.uid)
            }
        }
        
    }


struct Profile_Previews: PreviewProvider {
    static var previews: some View {
        Profile()
    }
}
