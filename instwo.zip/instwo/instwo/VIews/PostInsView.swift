//
//  PostInsView.swift
//  instwo
//
//  Created by 王建明 on 2021/8/21.
//

import SwiftUI

struct PostInsView: View {
    
    @Binding var offset: CGFloat

    var body: some View {
        ZStack{
            // Camera view...
            //Will Be implemented later...
            
            Color.black
            
            CameraView(offset: $offset)
            VStack{
                HStack{
                Button(action: {}, label: {
                    Image(systemName: "gear")
                        .font(.title)
                })
                    Spacer()
                
                Button(action: {
                    offset = rect.width
                }, label: {
                    Image(systemName: "xmark")
                        .font(.title)
                })
            }
            .foregroundColor(.white)
           Spacer()
                
                Button(action: {}, label: {
                    Image(systemName: "photo")
                        .font(.title)
                    
                })
                .foregroundColor(.white)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
        }
        .padding(.top,edges?.top ?? 15)
        .padding(.bottom,edges?.bottom)
    }
    }
}
struct PostInsView_Previews: PreviewProvider {
    static var previews: some View {
        MainInsView()
    }
}
