//
//  FeedViewIns.swift
//  instwo
//
//  Created by 王建明 on 2021/8/20.
//

import SwiftUI

struct FeedViewIns: View {
    @Binding var offset: CGFloat
    var body: some View {
        VStack{
            
            HStack{
                
                Button(action: {} , label: {
                    Image(systemName: "plus.app")
                        .font(.title)    //字体
                        .foregroundColor(.primary)  //颜色
                    
                })
                Spacer()
                
                Button(action: {
                    offset = rect.width * 2
                } , label: {
                    Image(systemName: "paperplane")
                        .font(.title)    //字体
                        .foregroundColor(.primary)  //颜色
                    
                })
            }
            
            .padding()
            .overlay(
                Text("Instagram")
                    .font(.title2)
                    .fontWeight(.bold)
            
            )
            
            ScrollView(.vertical, showsIndicators: false, content: {
                ScrollView(.horizontal, showsIndicators: false, content: {
                    
                    HStack(spacing: 15){  //
                        Button(action: {}, label: {
                            Image("logo")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 55, height: 55)
                                .clipShape(Circle())    //圆
                        })
                            .overlay(
                                Image(systemName: "plus.circle.fill")
                                    .font(.title)
                                    .foregroundColor(.blue)
                                    .background(Color.white
                                                    .clipShape(Circle()))   //白边
                                    .offset(x: 8, y: 5)  //偏移量
                                    
                                ,alignment: .bottomTrailing //右下角。  。bottonleading。为左下角
                                
                            
                            )
                    }
                    .padding()
                })
                Divider()
                   .padding(.horizontal, -15)      //分隔线
                
                VStack(spacing: 0){
                    //postins...
                    ForEach(posts){post in
                        //PostIns View...
                        
                        PostCardView(post: post)
                        
                        
                        
                    }
                    
                }
                .padding(.bottom, 65)    //排列间距
            })
        }
    }
}



struct PostCardView: View {
    
    
    var post: PostIns
    
    @State var comment = ""
    
    var body: some View {
        
        VStack(spacing: 15){
            
            HStack(spacing: 15){
                Image(post.profile)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 45,height: 45)
                    .clipShape(Circle())
                
                Text(post.user)
                    .fontWeight(.semibold)
                
                Spacer()     //占领最大空间
                
                Button(action: {}, label: {
                    Image(systemName: "line.horizontal.3")
                        .foregroundColor(.primary)
                })
                
                
            }
            
            Image(post.postImage)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: rect.width - 30, height: 300)   //屏幕宽度
                .cornerRadius(15)  //圆角
            
            HStack(spacing: 15) {
                Button(action: {}, label: {
                    Image(systemName: "suit.heart.fill")
                        .font(.system(size: 25))

                })
                Button(action: {}, label: {
                    Image(systemName: "paperplane")
                        .font(.system(size: 25))

                })
                
                Spacer()        //站位
                Button(action: {}, label: {
                    Image(systemName: "bookmark")
                        .font(.system(size: 25))

                })
                
            }
            .foregroundColor(.primary)    //黑色
            
            
            (
                
                //binding two Text
            
                Text("\(post.user)  ")
                    .fontWeight(.bold)
                
                +
                    Text(post.postTitle)
            )
            .frame(maxWidth: .infinity, alignment: .leading)    //左对齐
            
            .padding(6)
            
            HStack(spacing: 15){
                Image("logo")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 35, height: 35)
                    .clipShape(Circle())
                
                
                TextField("Add a comment...", text: $comment)
           }
            Text(post.time)
                .font(.caption)
                .fontWeight(.bold)
                .foregroundColor(.gray)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(6)
            
            
        
            
            
        }
        .padding()
        
        
    }
}
