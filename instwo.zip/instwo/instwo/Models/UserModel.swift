//
//  UserModel.swift
//  ins
//
//  Created by 王建明 on 2021/8/10.
//

import SwiftUI
import Foundation

struct User: Encodable, Decodable{     //编码，解码
    
    var uid: String
    var email: String
    var profileImageUrl: String
    var username: String
    var searchName: [String]
    var bio: String
}
