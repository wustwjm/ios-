//
//  PostIns.swift
//  instwo
//
//  Created by 王建明 on 2021/8/20.
//

import SwiftUI

//Post Model and data...


struct PostIns : Identifiable {
    var id = UUID().uuidString
    var user : String
    var profile: String
    var postImage : String
    var postTitle : String
    var time : String
    
}


var posts = [
    
    PostIns(user: "iJustine", profile: "p1", postImage: "post2", postTitle: "iphone11...", time: "58 min ago"),
    
    PostIns(user: "Capcon", profile: "p2", postImage: "post1", postTitle: "New Resident Evil Village...", time: "24 min ago"),
    PostIns(user: "Apple", profile: "p3", postImage: "post3", postTitle: "WWDC 2020 @ June 22", time: "1 house ago"),
    PostIns(user: "Catherine", profile: "p4", postImage: "post4", postTitle: "Nice day :)", time: "28 min ago"),
    PostIns(user: "UnBoxing", profile: "p5", postImage: "post5", postTitle: "New MacBook pro ", time: "2 min ago"),
    
  
    









]

