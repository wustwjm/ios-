//
//  Chat.swift
//  instwo
//
//  Created by 王建明 on 2021/8/17.
//

import Foundation
import Firebase
import SDWebImageSwiftUI

struct Chat: Encodable, Decodable, Hashable {
    
    var messageId: String
    var textMessage: String
    var profile: String
    var photoUrl: String
    var sender: String
    var username: String
    var timestamp: Double
    var isCurrentUser: Bool{
        return Auth.auth().currentUser!.uid == sender
    }
    
    var isPhoto: Bool
    
}
