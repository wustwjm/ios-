//
//  CommentModel.swift
//  instwo
//
//  Created by 王建明 on 2021/8/16.
//#20

import Foundation

struct CommentModel: Encodable, Decodable, Identifiable {      //可编码，可解码， 可识别
    
    var id = UUID()
    var profile: String
    var postId: String
    var username: String
    var date: Double
    var comment: String
    var ownerId: String
    
    
}
