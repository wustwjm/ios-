//
//  ContentView.swift
//  instwo
//
//  Created by 王建明 on 2021/8/11.
//

import SwiftUI


struct ContentView: View {
    var body: some View{
        MainInsView()
    }
}
    /*
    
    @EnvironmentObject var session: SessionStore
    


    
    func listen(){
        session.listen()
    }
    
//    @State private var maill = ""
//    @State private var password = ""
    
    var body: some View {
        Group{
            if(session.session != nil) {
                HomeView()
            } else {
                SignView()
            }
        }.onAppear(perform: listen)
    }
}
*/
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()//.environmentObject(SessionStore())
    }
}


var rect = UIScreen.main.bounds
var edges = UIApplication.shared.windows.first?.safeAreaInsets
