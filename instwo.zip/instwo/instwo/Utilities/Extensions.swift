//
//  Extensions.swift
//  ins
//
//  Created by 王建明 on 2021/8/10.
//编码和解码文字

import Foundation
//编码
extension Encodable{
    func asDictionary() throws -> [String: Any] {
        let data = try JSONEncoder().encode(self)
        
        guard let dictionary = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? [String: Any]
        else {
            throw NSError()
        }
        return dictionary
        
    }
}

//解码
extension Decodable{
    init(formDictionary: Any) throws{
        let data = try JSONSerialization.data(withJSONObject: formDictionary, options: .prettyPrinted)
        let decoder = JSONDecoder()
        self = try decoder.decode(Self.self , from: data)
    }
}
//传参数
extension String{
    func splitString() -> [String] {
        
        var stringArray: [String] = []
        let trimmend = String(self.filter{
            !" \n\t\r".contains($0)
        })
        for (index, _)in trimmend.enumerated(){
            let prefixIndex = index + 1
            let substringPrefix = String(trimmend.prefix(prefixIndex)).lowercased()
            stringArray.append(substringPrefix)
        }
        return stringArray
    }
    
    func removeWhiteSpace() -> String {
        return components(separatedBy: .whitespaces).joined()
    }
    
}

extension Date {
    func timeAgo() -> String {
        let formatter = DateComponentsFormatter()
        formatter.unitsStyle = .full
        formatter.allowedUnits = [.year, .month, .day, .hour, .minute, .second]
        
        
        formatter.zeroFormattingBehavior = .dropAll
        formatter.maximumUnitCount = 1
        return String(format: formatter.string(from: self, to: Date()) ?? "", locale: .current)
    }
}















/*
extension Error {
    var anthErrorValue: String{
        let errorcode = AuthErrorCode(rawValue: self._code)
        return errorcode!.stringValue
    }
}

extension AuthErrorCode {
    var stringValue: String {
        switch self {
        case .emailAlreadyInUse:
            return "user exists! please Login"
        case .invalidEmail:
            return "Please enter a valid email ID"
        case .userNotFound:
            return "No Account found. signup to continue"
        case .networkError:
            return "No internet"
        case .wrongPassword:
            return "Password invalid"
        case .weakPassword:
            return "Password should have minimun 6 characters"
        default:
            print("Error")
            
        }
    }
}
*/
